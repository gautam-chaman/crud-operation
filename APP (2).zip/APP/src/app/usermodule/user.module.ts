import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { LoginComponent } from './login.component';
import { WelcomeComponent } from './welcome.component';
import { RegistrationComponent } from './registration.component';
import { CommonModule } from '@angular/common';
import { UserModuleRouting } from './user.routemodule';
import { UserService } from './user.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from "@angular/forms";
@NgModule({
  declarations: [
    LoginComponent, RegistrationComponent, WelcomeComponent
  ],
  imports: [
    CommonModule, UserModuleRouting, HttpClientModule, FormsModule
  ],
  providers: [UserService],
  bootstrap: []
})
export class UserModule { }
