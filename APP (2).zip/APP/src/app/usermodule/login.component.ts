import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { UserModel } from './user.model';

@Component({
  selector: 'login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  constructor(private route: Router, private userService: UserService) {
    this.getAllData();
  }
  title = 'Login Page';
  userList: any;
  userModel: UserModel = new UserModel();
  loginUser() {
    this.userService.loginUser(this.userModel).subscribe(x => {
      if (x != null && x != undefined && x != '') {
        this.route.navigate(['/user/welcome']);
      }
      else
      {
        alert('Invalid user');
      }
    })

  }
  getAllData() {
    this.userService.getAllData().subscribe(x => {
      this.userList = x;
    })
  }
}
