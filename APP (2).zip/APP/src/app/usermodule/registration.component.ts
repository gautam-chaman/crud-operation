import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { UserModel } from './user.model';

@Component({
    selector: 'registration',
    templateUrl: './registration.component.html'
})
export class RegistrationComponent {
    constructor(private route: Router, private userService: UserService) {

    }
    title = 'Registration Page';
    userModel: UserModel = new UserModel();
    SaveData() {
        this.userService.saveData(this.userModel).subscribe(x => {
            if (x != null && x != undefined && x != '') {
                alert('Data Saved Succesfully');
                this.route.navigate(['/user/login']);
            }
            else {
                alert('Something went worng!!');
            }
        })
    }
}
