import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { map } from 'rxjs/operators';
@Injectable()
export class UserService {
    URL = "http://localhost:3000/";
    constructor(private htttp: HttpClient) {

    }
    saveData(obj) {
       return  this.htttp.post(this.URL + 'insertdata', obj).pipe(map(x => {
            return x;
        }));
    }
    getAllData() {
        return this.htttp.get(this.URL + 'readalldata').pipe(map(x => {
            return x;
        }));
    }
    getDataByUserId(id) {
        this.htttp.get(this.URL + 'readdatabyid/' + id)
    }
    loginUser(obj) {
        return this.htttp.post(this.URL + 'loginuser', obj).pipe(map(x => {
            return x;
        }));
    }
    deleteUser(obj) {
        this.htttp.delete(this.URL + 'deletedata', obj)
    }
    updateUser(obj) {
        this.htttp.put(this.URL + 'updatedata', obj)
    }
}